package Works;

import java.nio.file.Path;
import java.security.SecureRandom;

public class Main {
    public static void main(String[] args) throws Exception {

        //Путь к файлу
        Path inputPath = Path.of("C:/Users/Daniil/IdeaProjects/JavaLab/src/Works/warandpeace1.txt");
        byte[] input = TextToByte.readAllBytes(inputPath);

        //Ключи
        byte[] vigenereKey = "КЛЮЧ".getBytes(java.nio.charset.Charset.forName("windows-1251"));
        byte[] vernamKey = new byte[input.length];
        new SecureRandom().nextBytes(vernamKey);

        //Набор потоков 12 или 20
        int[] threadsToTest12 = {1,2,3,4,5,6,7,8,12};
        int[] threadsToTest20 = {1,2,4,5,8,10,16,20};

        //Выбор количества потоков для теста
        int[ ] threadsToTest = threadsToTest12;

        //Эталонное время. 1 поток
        System.out.println("n = " + input.length);

        //Шифр Вернама
        long t1 = Benchmark.timeNanos(() -> {
            byte[] out = Ciphres.vernamSingle(input, vernamKey);
            Benchmark.consume(out);
        }, 10, 50);        System.out.println("\nШифр Вернама:");
        System.out.printf("p = %d T=%.3f ms S=1.00 E=1.00%n", 1, t1/1e6);

        for (int p : threadsToTest){
            if (p == 1) continue;
            long tp = Benchmark.timeNanos(() -> {
               try {
                   byte[] out = Ciphres.vernamParallel(input, vernamKey, p);
                   Benchmark.consume(out);               } catch (InterruptedException e){
                throw new RuntimeException(e);
               }
            }, 2, 5);
            double S = (double) t1 / tp;
            double E = S / p;
            System.out.printf("p=%d  T=%.3f ms  S=%.2f  E=%.2f%n", p, tp/1e6, S, E);
        }

    }
}
